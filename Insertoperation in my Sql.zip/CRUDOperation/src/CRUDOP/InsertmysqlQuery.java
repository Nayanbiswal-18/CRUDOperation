package CRUDOP;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import InJDBCutil.JDBCutil;

public class InsertmysqlQuery{
	public static void main(String args[]) {
		Connection connection=null;
		PreparedStatement preparedstatement=null;
		
		try {
			connection=JDBCutil.getJdbcConnection();
			
			if(connection!=null) {
				
				String mysqlQuery="Insert into student(name,rollnum,result) values(?,?,?)";
				
				preparedstatement=connection.prepareStatement(mysqlQuery);
				
				if(preparedstatement!=null) {
					
					preparedstatement.setString(1, "Asutosh");
					preparedstatement.setInt(2, 06);
					preparedstatement.setString(3, "Fail");
					
					int roweffected=preparedstatement.executeUpdate();
					if(roweffected==1) {
						System.out.println("Row inserted");
					}else {
						System.out.println("Row not inserted");
						
					}
				}
		
			}
			
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCutil jdbCutil = new JDBCutil();
			try {
				jdbCutil.closeResource(connection, preparedstatement);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}